create
    definer = Sasha@localhost procedure filterByCreditLimit(IN limitCredit double)
BEGIN
select *
from customer
where creditLimit>limitCredit;

END;


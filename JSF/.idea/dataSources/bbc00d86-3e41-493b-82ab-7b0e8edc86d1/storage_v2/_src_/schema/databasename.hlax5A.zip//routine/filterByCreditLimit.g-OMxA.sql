create
    definer = Sasha@localhost procedure filterByCreditLimit(IN limitCredit double)
BEGIN
select creditLimit,
	   phone,
	   fullName
from customer
where creditLimit>limitCredit;

END;

